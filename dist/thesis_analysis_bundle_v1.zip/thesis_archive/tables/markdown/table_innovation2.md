| evidence_class     | method   |   mean_max_force |   relative_change |   harm_rate |
|:-------------------|:---------|-----------------:|------------------:|------------:|
| Independent formal | C0       |         0.342964 |          0        |    0        |
| Independent formal | E3-A     |         0.243956 |         -0.288684 |    0.253906 |
| Independent formal | E3-G     |         0.263107 |         -0.232844 |    0.183594 |
